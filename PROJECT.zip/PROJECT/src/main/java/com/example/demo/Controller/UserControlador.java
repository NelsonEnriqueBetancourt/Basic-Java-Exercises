package com.example.demo.Controller;


import com.example.demo.Models.User;
import com.example.demo.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/REST")//desactivar para hacer las pruebas del frotend al inicio sesion
public class UserControlador {

    @Autowired
    private UserService service;

    @RequestMapping(value = "/Users",method = RequestMethod.GET)
    public List<User>listUsers(){
        return service.listUsers();
    }

    @RequestMapping(value = "/User/{id}",method = RequestMethod.GET)
    public User obtenerUserid(@PathVariable Integer id){
        return service.obtenerUserid(id);
    }

    @RequestMapping(value = "/new",method = RequestMethod.POST)
    public void registrarUsers(@RequestBody User user){
        service.registrarUser(user);
    }

   @RequestMapping(value = "/User/{id}", method = RequestMethod.PUT)
    public ResponseEntity<?> updateUser(@RequestBody User user, @PathVariable Integer id){
        try{
            User UserExistente = service.obtenerUserid(id);
            service.registrarUser(user);
            return new ResponseEntity<User>(HttpStatus.OK);
        }catch (Exception exception){
            return new ResponseEntity<User>(HttpStatus.NOT_FOUND);
        }

    }

    @RequestMapping(value = "/Eliminar/{id}",method = RequestMethod.DELETE)
    public void EliminarUser(@PathVariable Integer id){
        service.EliminarUserid(id);
    }

    @RequestMapping(value = "/Users/page/{page}")
    public Page<User>listPage(@PathVariable Integer page){
        Pageable pageable= PageRequest.of(page,5);
        return service.listPage(pageable);
    }


}
