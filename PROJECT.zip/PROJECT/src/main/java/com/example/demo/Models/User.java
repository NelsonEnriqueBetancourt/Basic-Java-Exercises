package com.example.demo.Models;

import lombok.*;

import javax.persistence.*;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "USERS")
@ToString
@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "email")
    private String email;
    @Column(name = "password")
    private String password;
    @Column(name = "Name")
    private String Name;
    @Column(name = "lastName")
    private String lastName;
    @Column(name = "identification")
    private int identification;
    @Column(name = "address")
    private String address;
    @Column(name = "codeCity")
    private int codeCity;
    @Column(name = "city")
    private String city;
    @Column(name = "country")
    private String country;


}
