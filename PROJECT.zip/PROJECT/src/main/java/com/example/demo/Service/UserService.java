package com.example.demo.Service;

import com.example.demo.Models.User;
import com.example.demo.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements UserServicio{

    @Autowired
    private UserRepository repository;

    public List<User> listUsers(){
        return repository.findAll();
    }

    public User obtenerUserid(Integer id){
        return repository.findById(id).get();
    }

    public void registrarUser(User user){
        repository.save(user);
    }

    public void EliminarUserid(Integer id){
        repository.deleteById(id);
    }


    @Override
    public Page<User> listPage(Pageable pageable) {
        return repository.findAll(pageable);
    }

}
