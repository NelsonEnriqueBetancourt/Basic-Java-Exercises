package com.example.demo.Controller;


import com.example.demo.DAO.UserDAO;
import com.example.demo.Models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SesionController {

    @RequestMapping(value = "login")
    public String inicioSesion(){
        return "login";
    }

    @Autowired
    private UserDAO userDAO;

    @RequestMapping(value = "login",method = RequestMethod.POST)
    public String login(@RequestBody User user){
        if (userDAO.verificarCredenciales(user)){
            return "OK";
        }
        return "FAIL";
    }
}
