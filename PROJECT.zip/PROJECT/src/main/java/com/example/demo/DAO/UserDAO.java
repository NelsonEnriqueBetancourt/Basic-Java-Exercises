package com.example.demo.DAO;

import com.example.demo.Models.User;

import javax.transaction.Transactional;


public interface UserDAO {

    boolean verificarCredenciales(User user);


}
