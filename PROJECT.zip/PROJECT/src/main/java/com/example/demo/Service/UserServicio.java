package com.example.demo.Service;

import com.example.demo.Models.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface UserServicio {

    public Page<User> listPage(Pageable pageable);

}
