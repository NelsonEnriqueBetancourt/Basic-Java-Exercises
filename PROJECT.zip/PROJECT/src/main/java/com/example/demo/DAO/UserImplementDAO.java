package com.example.demo.DAO;

import com.example.demo.Models.User;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

@Transactional
@Service
public class UserImplementDAO implements UserDAO {

    @PersistenceContext
    EntityManager entityManager;



    @Override
    public boolean verificarCredenciales(User user) {
        String query = "FROM User WHERE email = :email AND password = :password";
        List<User>list=entityManager.createQuery(query)
                .setParameter("email",user.getEmail())
                .setParameter("password",user.getPassword())
                .getResultList();

        return !list.isEmpty();
    }
}
