$(document).ready(function() {


});


async function registrarUsuario(){
    let datos={};
    datos.name= document.getElementById('txtNombre').value;
    datos.lastName= document.getElementById('txtApellido').value;
    datos.identification= document.getElementById('txtidentificacion').value;
    datos.address= document.getElementById('txtDireccion').value;
    datos.codeCity= document.getElementById('txtCodigopostal').value;
    datos.city= document.getElementById('txtCiudad').value;
    datos.country= document.getElementById('txtPais').value;
    datos.email= document.getElementById('txtEmail').value;
    datos.password= document.getElementById('txtContraseña').value;

    let repetirContraseña = document.getElementById('txtrepetirContraseña').value;

    if(repetirContraseña != datos.password){
        alert ('¡RELLENE TODOS LOS CAMPOS!');

    }

  const request = await fetch('/new', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
      body: JSON.stringify(datos)
  });


  alert('Se Registro Con Exito');
  window.location.href='login.html'

}
