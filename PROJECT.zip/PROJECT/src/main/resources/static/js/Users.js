// Call the dataTables jQuery plugin
$(document).ready(function() {
    cargarUsuarios();
  $('#Users').DataTable();
});


async function cargarUsuarios(){
  const request = await fetch('/Users', {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    }
  });
  const Users = await request.json();

  let listadoHtml ='';
  for(let User of Users){
    let usuarioHtml  =  '<tr> <td>'+User.id+'</td><td>'+ User.email +'</td><td>'+ User.password
                        +'</td><td>'+User.name+'</td><td>'+User.lastName
                        +'</td><td>'+User.identification +'</td><td>'+User.address+'</td><td>'+User.codeCity
                        +'</td><td>'+User.city+'</td><td>'+User.country+'</td></tr>';
    listadoHtml += usuarioHtml;
  }

document.querySelector('#Users tbody').outerHTML=listadoHtml;


}

