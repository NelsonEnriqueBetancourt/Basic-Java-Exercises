$(document).ready(function() {

});

async function iniciarSesion(){
    let datos={};
    datos.email= document.getElementById('txtemail').value;
    datos.password= document.getElementById('txtContraseña').value;


  const request = await fetch('login', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
      body: JSON.stringify(datos)
  });

  const respuesta = await request.text();
  if(respuesta == 'OK'){

      window.location.href='inicio.html'

  }else{
      alert("las credenciales son incorrectas. intente nuevamente.");
  }


}
