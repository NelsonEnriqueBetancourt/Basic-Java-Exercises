package com.example.demo;


import com.example.demo.Models.User;
import com.example.demo.Repository.UserRepository;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;


@DataJpaTest//le indicamos que esta clase va hacer una prueba de nuestra entidad
//@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)//indicamos que vamos a trabajar con la base de datos que esta definida
public class UserTest {

    @Autowired
    private UserRepository repository;



    @Test
    public void TestListUsers(){
        List<User> list= repository.findAll();//le indicamos que nos liste todos los usuarios que existen en la base de datos

        for (User user : list){
            System.out.println(user);//con este for-each mandamos a mostrar por consola los registros de usuarios en la base de datos
        }
        assertThat(list).size().isGreaterThan(0);//le indicamos que esta lista se va a confirmar si es mayor a 0

    }

    @Test
    public void TestBuscarUseridExistente(){
        Integer id =19;//le indicamos el id que esta registrado en la base de datos con su usuario

        User user= repository.getById(id);//buscamos el usuario en el cual le indicamos que si existe

        assertNotNull(user);//confirmar que si este usuario si existe
    }

    @Test
    public void TestBuscarUseridNoExistente(){//para probar que no existe ninguno usuario con ese id
        Integer id =19; //ponemos un id que no este registrado en la base de datos

        User user= repository.getById(id);

        assertNotNull(user);
        //assertNull(user);//confirmar que  este usuario no existe
    }


    @Test//le indicamos que este metodo va hacer una prueba
    @Rollback(value = false)//
    public void TestRegistrarUsers(){//creamos un objeto de la clase user y le ponemos los datos
        User user = new User(21,"ee","ooo","pepe","lopez",221,"comfenalco",221,"ibague","colombia");
        User userguardado= repository.save(user);//le indicamos que este nuevo usuario lo guarde

        assertNotNull(userguardado);//le indicamos que este usuario no puede ser null
    }



    @Test
    @Rollback(value = false)
    public void TestEliminarUser(){
        Integer id =21;//pasamos el id del usuario a eliminar

        boolean esExistenteAntesDeEliminar= repository.findById(id).isPresent();//true, mediante esta condicion le decimos que si existe

        repository.deleteById(id);//ejecutamos la accion a la base de datos

        boolean noExistenteAntesDeEliminar= repository.findById(id).isPresent();//false, mediante esta condicion le decimos que no existe

        assertTrue(esExistenteAntesDeEliminar);
        assertFalse(noExistenteAntesDeEliminar);

    }

    @Test//le indicamos que este metodo va hacer una prueba
    @Rollback(value = false)//
    public void TestUpdateUsers(){

        String nombreUser ="Sebastian";//nuevo nombre

        User user = new User(19,"ee","ooo",nombreUser,"lopez",221,"comfenalco",222,"POLONIA","COLOMBIA");//valores nuevos
        user.setId(19);//id del producto a actualizar o modificar

        repository.save(user);//guardamos los cambios o nuevos registros

        User userActualizado=repository.getById(user.getId());
        assertThat(userActualizado.getName()).isEqualTo(nombreUser);
    }






}
